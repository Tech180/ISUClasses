package edu.iastate.cpre388.memoryleak;

import java.util.ArrayList;
import java.util.List;

public class BagOfCats {
    public static final List<Cat> bag = new ArrayList<>();
}
