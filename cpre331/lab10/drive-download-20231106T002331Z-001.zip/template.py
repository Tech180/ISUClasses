# ISU Lottory generates two lottery numbers every other day.
# The formula for generating these random numbers has been kept secret until
# a curious cpre231 student hacked into their database and leaked the
# code they used to generate their lottery numbers
import random


#Generates a winning lottery number for today and tomorrow
def generateLottery(dateOfGeneration, timeInSeconds):
    # timeInSeconds = [0, 1, ..., 86400]
    # dateOfGeneration = MM/DD/YYYY
    lotteryNumbers = []

    # Add the date and the seconds to get the seed
    random.seed(int(dateOfGeneration.replace("/","")) + timeInSeconds)

    # Generate lottery number for the current day
    randomNumbers = []
    for i in range(10):
        randomNumbers.append(str(random.randrange(0, 10)))
    lotteryNumbers.append('-'.join(randomNumbers))

    # Generate lottery number for the next day
    randomNumbers = []
    for i in range(10):
        randomNumbers.append(str(random.randrange(0, 10)))
    lotteryNumbers.append('-'.join(randomNumbers))

    #Return an array of two values
    #lotteryNumbers[0] = Today's lottery number
    # lotteryNumbers[1] = Tomorrow's lottery number
    return lotteryNumbers




def main():

    #winningNumber = "5-4-3-1-2-9-1-4-2-5"

    dateOfGeneration = "11/12/2023"

    timeInSeconds = 86400

    winning = generateLottery(dateOfGeneration, timeInSeconds)

    #TODO: Implement here
    print("Winning Lottery Ticket for November 11th, 2023:", winning[0])
    print("Winning Lottery Ticket for November 12th, 2023:", winning[1])

if __name__ == '__main__':
    main()
