#include <stdio.h>

void main() {
    puts("Hello world");
}
