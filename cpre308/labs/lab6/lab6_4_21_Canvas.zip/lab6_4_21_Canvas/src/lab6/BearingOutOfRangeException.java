package lab6;

public class BearingOutOfRangeException extends RuntimeException {
	private static final long serialVersionUID = 1L;

}
